Pkg7 - 3 installable c, b, a
Pkg7 with Merge = same as 7 but a and g packages require merging dependencies
Pkg48 - 20 installable *special case self dependency, does not install
Pkg877 - All installable, good test case for time comparison
Pkg1000 - 105 installable
Pkg3000 - 713 installable
Pkg4131 - 4131 installable
PkgMystery - ?? You tell me..